package task;

public class ClientInfo {
    
}
