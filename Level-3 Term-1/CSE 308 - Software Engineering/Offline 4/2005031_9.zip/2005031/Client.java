package task;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;


class ClientThread implements Runnable {
    Socket socket;
    ObjectInputStream ois;
    Thread t;
    ClientThread (Socket socket, ObjectInputStream ois) {
        this.socket = socket;
        this.ois = ois;
        this.t = new Thread(this);
        t.start();
    }
    @Override
    public void run() {
        try {
        boolean loopend = true;
        while(loopend) {
            Object obj=null;
            obj = ois.readObject();
            
            DataWrapper dataWrapper = (DataWrapper) obj;
            switch (dataWrapper.getDataType()) {
                case "Logout":
                    loopend = false;
                    break;
                case "Message":
                    System.out.println((String)dataWrapper.getObject());
                    break;
                case "All_Stock_Data":
                case "Client_Stocks":
                    System.out.println("Stock List:");
                    for(StockInfo stockInfo: (ArrayList<StockInfo>)dataWrapper.getObject())
                        System.out.println(stockInfo.getName()+" "+stockInfo.getCount()+" "+stockInfo.getPrice()+" ");
                    System.out.println();
                    break;
                case "Notifications":
                    if(((ArrayList<String>)dataWrapper.getObject()).size()>0)
                        System.out.println("Notification List:");
                    for(String notification: (ArrayList<String>)dataWrapper.getObject())
                        System.out.println(notification);
                    System.out.println();
                    break;
            
                default:
                    System.out.println("Invalid type");
                    break;
            }
        }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }
}

public class Client {
    public static void main(String[] args) {
        try {
            // initialization
            Scanner sc = new Scanner (System.in);
            System.out.println("Client started...");
            Socket socket = null;
            ObjectInputStream ois = null;
            ObjectOutputStream oos = null;

            // connection
            socket = new Socket("127.0.0.1",6000);
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());
            System.out.println("Client connected...");

            // main loop
            while(true) {

                // input username type exit to exit
                System.out.print("Username: ");
                String name = sc.nextLine();
                if (name.equals("exit"))
                    break;
                
                // input password
                System.out.print("Password: ");
                String password = sc.nextLine();

                // send login info to server
                LoginInfo loginInfo = new LoginInfo(name, password);
                oos.writeObject(loginInfo);

                // start read thread
                new ClientThread(socket, ois);

                // loop for getting input from command line and sending to server
                while(true) {
                    // wait for execution
                    Thread.sleep(1000);

                    // promt and input
                    System.out.print("Command: ");
                    String line = sc.nextLine();
                    System.out.println();

                    // send input to server
                    oos.writeObject(line);

                    // logout
                    if (line.equals("logout"))
                        break;
                }
            }
            sc.close();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            System.exit(-2);
        }
    }
}
