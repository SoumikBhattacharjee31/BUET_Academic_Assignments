// package
package task;

// imports
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

// server thread for all io operations between server and client
class ServerThread implements Runnable {

    // member variables
    String username;
    String password;
    Socket socket;
    Thread t;
    ObjectInputStream ois;
    ObjectOutputStream oos;
    boolean admin = false;

    // constructor
    ServerThread (Socket socket) throws IOException {
        this.socket = socket;
        this.ois = new ObjectInputStream(socket.getInputStream());
        this.oos = new ObjectOutputStream(socket.getOutputStream());
        this.t = new Thread(this);
        t.start();
    }

    // admin function
    

    

    void view () throws Exception {
        // get stock list
        ArrayList<StockInfo> stockInfoList = new ArrayList<>();
        for (String key : Server.stockDatabase.getStocks().keySet()) {
            Stock stock6 = Server.stockDatabase.getStock(key);
            for (User user : stock6.getUserList()) {
                if(user.getName().equals(this.username)) {
                    StockInfo stockInfo = new StockInfo(stock6.getName(), stock6.getCount(), stock6.getPrice());
                    stockInfoList.add(stockInfo);
                    break;
                }
            }
        }

        // sendstock list
        this.oos.writeObject(new DataWrapper("Client_Stocks", stockInfoList));
    }

    @Override
    public void run () {
        try {
            while (true) {
                
                // get login info
                LoginInfo loginInfo = (LoginInfo)ois.readObject();
                this.username = loginInfo.getUsername();
                this.password = loginInfo.getPassword();

                // admin login
                if (username.equals(Server.admin.getName()) && password.equals(Server.admin.getPassword())) {
                    admin = true;
                    this.oos.writeObject(new DataWrapper("All_Stock_Data",Server.stockDatabase.getStockInfoList()));
                }

                // member login
                else {
                    User user = Server.userDatabase.getUser(username, password);

                    // sign up
                    if (user==null) {
                        this.oos.writeObject(new DataWrapper("Message","Username or password doesn't match\nCreating a new account"));
                        Server.userDatabase.addNewUser(username, password);
                        user = Server.userDatabase.getUser(username, password);
                    }

                    // log in
                    else
                        this.oos.writeObject(new DataWrapper("Message","Logged In"));
                    
                    // initialize if user's first socket
                    if (!Server.socketMap.containsKey(username)) 
                        Server.socketMap.put(username, new ArrayList<>());
                    
                    // add socket to database
                    Server.socketMap.get(username).add(new SocketWrapper(username, password, socket, ois, oos));

                    // send data needs to be sent after login
                    this.oos.writeObject(new DataWrapper("All_Stock_Data",Server.stockDatabase.getStockInfoList()));
                    this.oos.writeObject(new DataWrapper("Notifications", new ArrayList<>(Server.userDatabase.getUserByName(username).getNotifications())));
                    Server.userDatabase.getUserByName(username).getNotifications().clear();
                }
                
                // init loop
                boolean loopout = true;
                while (loopout) {
                    // read and tokenize instruction
                    Object messageObj = ois.readObject();
                    String message = (String) messageObj;
                    String[] tokens = message.split(" ");
                    if(tokens.length<1) {
                        System.out.println("Invalid input");
                        continue;
                    }

                    if (messageObj.equals("logout")) {
                        // remove socket
                        for (SocketWrapper sw : Server.socketMap.get(username))
                            if(sw.getSocket()==this.socket) {
                                Server.socketMap.get(username).remove(sw);
                                oos.writeObject(new DataWrapper("Logout","User successfully logged out"));
                                break;
                            }
                        loopout = false;
                        break;
                    }

                    if(admin)
                        Server.admin.changeStock(tokens, oos);
                    
                    else{
                        // switch operation
                        switch (tokens[0]) {
                            case "S":
                            case "U":
                                Server.userDatabase.getUserByName(username).subscribeOrUnSubscribe(tokens,oos);
                                break;
                            case "V":
                                view();
                                break;
                            default:
                                oos.writeObject(new DataWrapper("Message","Invalid command"));
                                break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        for(SocketWrapper sw : Server.socketMap.get(this.username))
            if (sw.getSocket().equals(this.socket)) {
                Server.socketMap.get(this.username).remove(sw);
                break;
            }
    }
}

// socketwrapper class that stores data of a socket
class SocketWrapper {
    String username;
    String password;
    Socket socket;
    ObjectInputStream ois;
    ObjectOutputStream oos;
    SocketWrapper(String username, String password, Socket socket, ObjectInputStream ois, ObjectOutputStream oos) {
        this.username = username;
        this.password = password;
        this.socket = socket;
        this.ois = ois;
        this.oos = oos;
    }
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    public Socket getSocket() {
        return socket;
    }
    public ObjectInputStream getOis() {
        return ois;
    }
    public ObjectOutputStream getOos() {
        return oos;
    }
}

// Server class
public class Server {

    // database
    static HashMap<String, ArrayList<SocketWrapper>> socketMap;
    static StockDatabase stockDatabase;
    static UserDatabase userDatabase;
    static ServerSocket serverSocket;
    static Admin admin;

    // static initialization
    static {
        socketMap = new HashMap<>();
        stockDatabase = new StockDatabase();
        userDatabase = new UserDatabase();
        serverSocket = null;
        admin = Admin.createAdmin("admin", "password");
    }

    // main function
    public static void main(String[] args) throws IOException {

        try {
            // initialization
            Scanner sc = new Scanner(new File("init_stocks.txt"));
            
            // read file
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] tokens = line.split(" ");
                stockDatabase.addNewStock(tokens[0], Integer.parseInt(tokens[1]), Double.parseDouble(tokens[2]));
            }

            // create serversocket
            serverSocket = new ServerSocket(6000);
            System.out.println("Server started");
            
            // loop for accepting clients
            while(true) {
                try {

                    // connection
                    Socket socket = serverSocket.accept();
                    System.out.println("User connected");

                    // new thread
                    new ServerThread(socket);

                } catch (IOException e) {
                    System.out.println("Error: "+e);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}