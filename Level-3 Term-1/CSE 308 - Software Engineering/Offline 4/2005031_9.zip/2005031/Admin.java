package task;

import java.io.ObjectOutputStream;

// admin class
class Admin {
    // member variables
    String name;
    String password;
    StockDatabase stockDatabase;
    static Admin singleAdmin=null;

    // constructor
    private Admin (String name, String password) {
        this.name = name;
        this.password = password;
        this.stockDatabase = new StockDatabase();
    }

    // singleton creator
    public static Admin createAdmin (String name, String password) {
        if (singleAdmin==null)
            singleAdmin = new Admin(name, password);
        return singleAdmin;
    }

    // getter
    public String getName() {
        return name;
    }
    public String getPassword() {
        return password;
    }
    public StockDatabase getStockDatabase() {
        return stockDatabase;
    }
    public static Admin getSingleAdmin() {
        return singleAdmin;
    }

    // setter
    public void setName(String name) {
        this.name = name;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setStockDatabase(StockDatabase stockDatabase) {
        this.stockDatabase = stockDatabase;
    }
    public static void setSingleAdmin(Admin singleAdmin) {
        Admin.singleAdmin = singleAdmin;
    }

    void changeStock (String[] tokens, ObjectOutputStream oos) throws Exception {
        // get stock using stock name
        Stock stock = Server.stockDatabase.getStock(tokens[1]);
        if (tokens.length<3) {
            oos.writeObject(new DataWrapper("Message","Invalid number of arguments"));
            return;
        }

        // type cast number
        double amount = 0;
        try{
            amount = Double.parseDouble(tokens[2]);   
        } catch (Exception e) {
            oos.writeObject(new DataWrapper("Message","The input must be a number"));
            return;
        }

        // check negative number
        if (amount<0) {
            oos.writeObject(new DataWrapper("Message","Amount must be non-negative"));
            return;
        }

        // set
        switch (tokens[0]) {
            case "I":
                stock.setPrice(stock.getPrice()+amount);
                break;
            case "D":
                // check negative price result
                if (stock.getPrice()<amount) {
                    oos.writeObject(new DataWrapper("Message","Cannot decrease more than "+stock.getPrice()));
                    return;
                }
                stock.setPrice(stock.getPrice()-amount);
                break;
            case "C":
                stock.setCount((int)amount);
                break;
            default:
                oos.writeObject(new DataWrapper("Message","Invalid command"));
                return;
        }

        // return success message
        oos.writeObject(new DataWrapper("Message","Operation successful"));
    }
}
