package task;

import java.io.ObjectOutputStream;
import java.util.ArrayList;

class User {
    String name;
    String password;
    ArrayList<Stock> subscribedStocks;
    ArrayList<String> notifications;

    User (String name, String password) {
        this.name = name;
        this.password = password;
        this.notifications = new ArrayList<>();
        this.subscribedStocks = new ArrayList<>();
    }

    public String getName() {
        return name;
    }
    public String getPassword() {
        return password;
    }
    public ArrayList<Stock> getSubscribedStocks() {
        return subscribedStocks;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setSubscribedStocks(ArrayList<Stock> subscribedStocks) {
        this.subscribedStocks = subscribedStocks;
    }

    void addNotification (String notification) {
        this.notifications.add(notification);
    }
    public ArrayList<String> getNotifications() {
        return notifications;
    }

    void notifyUser (String message) throws Exception {

        // save notification
        Server.userDatabase.getUserByName(this.name).addNotification(message);

        // send notification
        Boolean open = false;
        for (SocketWrapper sw : Server.socketMap.get(this.name)) {
            open = true;
            sw.getOos().writeObject(new DataWrapper("Notifications",new ArrayList<>(Server.userDatabase.getUserByName(this.name).getNotifications())));
        }

        // remove notification if already sent
        if(open)
            Server.userDatabase.getUserByName(this.name).getNotifications().clear();
    }

    void subscribeOrUnSubscribe (String[] tokens, ObjectOutputStream oos) throws Exception {
        
        // get stock using stock name
        Stock stock = Server.stockDatabase.getStock(tokens[1]);
        
        // check if username is subscribed
        for (User user : stock.getUserList())
            if(user.getName().equals(this.name)) {
                if (tokens[0].equals("U")) {
                    stock.getUserList().remove(user);
                    oos.writeObject(new DataWrapper("Message","User successfully unsubscribed"));
                }
                else
                    oos.writeObject(new DataWrapper("Message","User already subcribed"));
                return;
            }
        
        // subscribe or result
        if (tokens[0].equals("S")) {
            stock.getUserList().add(Server.userDatabase.getUserByName(this.name));
            oos.writeObject(new DataWrapper("Message","User successfully subcribed"));
        }
        else
            oos.writeObject(new DataWrapper("Message","User already unsubcribed"));
    }
}
