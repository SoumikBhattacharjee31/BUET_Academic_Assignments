package task;

import java.io.Serializable;

class StockInfo implements Serializable {

    // member variables
    private String name;
    private int count;
    private double price;

    // constructor
    StockInfo (String name, int count, double price) {
        this.name = name;
        this.count = count;
        this.price = price;
    }

    // getters
    public String getName() {
        return name;
    }
    public int getCount() {
        return count;
    }
    public double getPrice() {
        return price;
    }

    public String toString () {
        return name + " " + count + " " + price;
    }
}