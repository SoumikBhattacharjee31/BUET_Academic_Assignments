package task;

import java.util.ArrayList;
import java.util.HashMap;

class StockDatabase {
    HashMap<String,Stock> stocks;

    StockDatabase () {
        this.stocks = new HashMap<>();
    }

    boolean addNewStock (String name, int count, double value) {
        if (this.stocks.containsKey(name))
            return false;
        this.stocks.put(name, new Stock(name, count, value));
        return true;
    }

    Stock getStock (String name) {
        if (this.stocks.containsKey(name))
            return this.stocks.get(name);
        return null;
    }

    HashMap<String,Stock> getStocks() {
        return stocks;
    }

    ArrayList<StockInfo> getStockInfoList () {
        ArrayList<StockInfo> stockInfoList = new ArrayList<>();
        for(String key : this.stocks.keySet()) {
            Stock stock = this.stocks.get(key);
            StockInfo stockInfo = new StockInfo(stock.getName(), stock.getCount(), stock.getPrice());
            stockInfoList.add(stockInfo);
        }
        return stockInfoList;
    }
}
