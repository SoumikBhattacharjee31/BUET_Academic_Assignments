package task;

import java.io.Serializable;

public class DataWrapper implements Serializable {
    String dataType;
    Object object;

    DataWrapper(String dataType, Object object) {
        this.dataType = dataType;
        this.object = object;
    }

    public String getDataType() {
        return dataType;
    }
    public Object getObject() {
        return object;
    }
}
