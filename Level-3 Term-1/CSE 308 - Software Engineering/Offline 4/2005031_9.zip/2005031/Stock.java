package task;

import java.util.ArrayList;

class Stock {

    // member variables
    private String name;
    private int count;
    private double price;
    ArrayList<User> userList;

    // constructor
    Stock (String name, int count, double price) {
        this.name = name;
        this.count = count;
        this.price = price;
        this.userList = new ArrayList<>();
    }

    // getters
    public String getName() {
        return name;
    }
    public int getCount() {
        return count;
    }
    public double getPrice() {
        return price;
    }
    public ArrayList<User> getUserList() {
        return this.userList;
    }

    // setters
    synchronized public void setName(String name) {
        this.name = name;
    }
    synchronized public void setCount(int count) throws Exception {
        this.count = count;
        String message = "Count of stock "+name+" has changed to "+count;
        notifyUsers(message);
    }
    synchronized public void setPrice (double price) throws Exception {
        this.price = price;
        String message = "Price of stock "+name+" has changed to "+price;
        notifyUsers(message);
    }
    synchronized public void setUserList(ArrayList<User> userList) {
        this.userList = new ArrayList<>();
        for(User user: userList)
            this.userList.add(user);
    }

    public void notifyUsers (String message) throws Exception {
        for (User user : getUserList())
            user.notifyUser(message);
    }

    public String toString () {
        return name + " " + count + " " + price;
    }
}