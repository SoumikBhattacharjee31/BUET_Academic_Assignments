package task;

import java.util.HashMap;

class UserDatabase {
    HashMap<String,User> users;
    

    UserDatabase() {
        this.users = new HashMap<>();
    }

    boolean addNewUser (String name, String password) {
        if (this.users.containsKey(name))
            return false;
        this.users.put(name, new User(name, password));
        return true;
    }
    

    User getUser (String name, String password) {
        if (this.users.containsKey(name)) {
            User temp = this.users.get(name);
            if (temp.getPassword().equals(password))
                return temp;
        }
        return null;
    }
    User getUserByName (String name) {
        if (this.users.containsKey(name))
            return this.users.get(name);
        return null;
    }

    
}