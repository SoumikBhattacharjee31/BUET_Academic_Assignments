public enum EnumIceCreamType {
    Chocolate, Strawberry
}