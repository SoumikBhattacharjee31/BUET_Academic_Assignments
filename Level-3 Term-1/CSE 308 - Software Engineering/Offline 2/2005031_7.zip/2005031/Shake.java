class Shake {
    // member variables
    EnumShakeType shakeType;
    EnumMilkType milkType;
    EnumSugarType sugarType;
    EnumSyrupType syrupType;
    EnumIceCreamType iceCreamType;
    Boolean coffee;
    EnumJelloType jelloType;
    Boolean vanillaFlavouring;
    Boolean candy;
    Boolean cookies;
    double basePrice;
    ExtraCostList extraCostList;

    // constructors
    Shake (EnumShakeType shakeType, EnumMilkType milkType, EnumSugarType sugarType, EnumSyrupType syrupType, EnumIceCreamType iceCreamType, Boolean coffee,
            EnumJelloType jelloType, Boolean vanillaFlavouring, Boolean candy, Boolean cookies, double basePrice, ExtraCostList extraCostList) {
        this.shakeType = shakeType;
        this.milkType = milkType;
        this.sugarType = sugarType;
        this.syrupType = syrupType;
        this.iceCreamType = iceCreamType;
        this.coffee = coffee;
        this.jelloType = jelloType;
        this.vanillaFlavouring = vanillaFlavouring;
        this.candy = candy;
        this.cookies = cookies;
        this.basePrice = basePrice;
        this.extraCostList = new ExtraCostList();
        this.extraCostList.getExtraCostList().putAll(extraCostList.getExtraCostList());
    }

    // printing shake details
    void print () {
        // divider
        System.out.println();
        for (int i=0;i<20;i++)
            System.out.print("#");
        System.out.println();

        // shake type
        System.out.println("Shake type: " + shakeType);

        // divider
        for (int i=0;i<20;i++)
            System.out.print("=");
        System.out.println();

        // ingrediants
        System.out.println("Ingrediants:");
        // divider
        for (int i=0;i<20;i++)
            System.out.print("-");
        System.out.println();
        if(milkType == EnumMilkType.Normal) System.out.println(milkType + " milk");
        if(sugarType != null) System.out.println(sugarType + (sugarType==EnumSugarType.Sweetener?"":" sugar"));
        if(syrupType != null) System.out.println(syrupType + " syrup");
        if(iceCreamType != null) System.out.println(iceCreamType + " ice cream");
        if(coffee != false) System.out.println("Coffee");
        if(jelloType != null) System.out.println(jelloType + " jello");
        if(vanillaFlavouring) System.out.println("Vanilla flavouring");

        // divider
        for (int i=0;i<20;i++)
            System.out.print("=");
        System.out.println();

        // extra ingrediants
        if(!extraCostList.empty()){
            System.out.println("Extra ingrediants:");
            // divider
            for (int i=0;i<20;i++)
                System.out.print("-");
            System.out.println();
        }
        if(milkType == EnumMilkType.Almond) System.out.println("Almond Milk : "+extraCostList.get("Almond Milk"));
        if(candy) System.out.println("Candy : "+extraCostList.get("Candy"));
        if(cookies) System.out.println("Cookies : "+extraCostList.get("Cookies"));

        // base price
        System.out.println("Base price: "+basePrice);

        // divider
        for (int i=0;i<20;i++)
            System.out.print("=");
        System.out.println();

        // total price
        System.out.println("Total price: "+(basePrice+extraCostList.getTotalPrice()));

        // divider
        for (int i=0;i<20;i++)
            System.out.print("#");
        System.out.println();
        System.out.println();
    }
}