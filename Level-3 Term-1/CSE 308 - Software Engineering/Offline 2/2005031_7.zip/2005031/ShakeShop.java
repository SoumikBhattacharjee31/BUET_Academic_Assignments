// shake shop handling shop functions

public class ShakeShop {
    // member variable
    ShakeDirector shakeDirector;
    ShakeOrderList shakeOrderList;
    ExtraCostList extraCostList;
    ShakeBuilder shakeBuilder;

    // constructor
    ShakeShop() {
        shakeDirector = null;
        this.shakeOrderList = null;
        this.extraCostList = null;
        this.shakeBuilder = null;
    }

    // start order list
    public void startOrderList () {
        shakeOrderList = new ShakeOrderList();
    }

    // start each order
    public void startOrder () {
        shakeDirector = new ShakeDirector();
        shakeBuilder = new ShakeBuilder();
        extraCostList = new ExtraCostList();
    }

    // setting default type of shake
    public Boolean typeOfShake (String type) {
        type = type.substring(0,1).toUpperCase() + type.substring(1).toLowerCase();
        switch (type) {
            case "Chocolate":
                shakeDirector.setChocolateShake(shakeBuilder);
                break;
            case "Coffee":
                shakeDirector.setCoffeeShake(shakeBuilder);
                break;
            case "Strawberry":
                shakeDirector.setStrawberryShake(shakeBuilder);
                break;
            case "Vanilla":
                shakeDirector.setVanillaShake(shakeBuilder);
                break;
            case "Zero":
                shakeDirector.setZeroShake(shakeBuilder);
                break;
            default:
                return false;
        }
        return true;
    }

    // making lactose free
    public void makeLactoseFree () {
        shakeDirector.setLactoseFree(shakeBuilder);
        extraCostList.add("Almond Milk", 60);
    }

    // adding candy
    public void addCandyOnTop () {
        shakeDirector.setCandyOnTop(shakeBuilder);
        extraCostList.add("Candy", 50);
    }

    // adding cookies
    public void addCookiesOnTop () {
        shakeDirector.setCookiesOnTop(shakeBuilder);
        extraCostList.add("Cookies", 40);
    }

    // 
    public void closeOrder () {
        shakeDirector.setExtraCostList(shakeBuilder, extraCostList);
        shakeOrderList.add(shakeBuilder.getShake());
        shakeBuilder = null;
        shakeDirector = null;
        extraCostList = null;
    }
    public void closeOrderList () {
        shakeOrderList.print();
        shakeOrderList = null;
    }
}