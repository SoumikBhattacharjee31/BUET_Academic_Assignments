public enum EnumMilkType {
    Normal, Almond
}