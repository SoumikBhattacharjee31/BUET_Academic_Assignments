class ShakeBuilder {
    // member variables
    EnumShakeType shakeType;
    EnumMilkType milkType;
    EnumSugarType sugarType;
    EnumSyrupType syrupType;
    EnumIceCreamType iceCreamType;
    Boolean coffee;
    EnumJelloType jelloType;
    Boolean vanillaFlavouring;
    Boolean candy;
    Boolean cookies;
    double basePrice;
    ExtraCostList extraCostList;

    // constructor assigns all to null
    ShakeBuilder () {
        this.shakeType = null;
        this.milkType = null;
        this.sugarType = null;
        this.syrupType = null;
        this.iceCreamType = null;
        this.coffee = false;
        this.jelloType = null;
        this.vanillaFlavouring = false;
        this.candy = false;
        this.cookies = false;
        this.basePrice = 0;
        this.extraCostList = new ExtraCostList();
    }

    // setters
    public void setShakeType(EnumShakeType shakeType) {
        this.shakeType = shakeType;
    }
    public void setMilkType(EnumMilkType milkType) {
        this.milkType = milkType;
    }
    public void setSugarType(EnumSugarType sugarType) {
        this.sugarType = sugarType;
    }
    public void setSyrupType(EnumSyrupType syrupType) {
        this.syrupType = syrupType;
    }
    public void setIceCreamType(EnumIceCreamType iceCreamType) {
        this.iceCreamType = iceCreamType;
    }
    public void setCoffee(Boolean coffee) {
        this.coffee = coffee;
    }
    public void setJelloType(EnumJelloType jelloType) {
        this.jelloType = jelloType;
    }
    public void setVanillaFlavouring(Boolean vanillaFlavouring) {
        this.vanillaFlavouring = vanillaFlavouring;
    }
    public void setCandy(Boolean candy) {
        this.candy = candy;
    }
    public void setCookies(Boolean cookies) {
        this.cookies = cookies;
    }
    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }
    public void setExtraCostList(ExtraCostList extraCostList) {
        this.extraCostList.getExtraCostList().putAll(extraCostList.getExtraCostList());;
    }

    // building shake
    public Shake getShake () {
        return new Shake (shakeType, milkType, sugarType, syrupType, iceCreamType, coffee,
            jelloType, vanillaFlavouring, candy, cookies, basePrice, extraCostList);
    }
}