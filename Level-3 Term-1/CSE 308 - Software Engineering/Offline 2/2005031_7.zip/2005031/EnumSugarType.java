public enum EnumSugarType {
    Normal, Sweetener
}