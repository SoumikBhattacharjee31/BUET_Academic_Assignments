// Shake Director
class ShakeDirector {
    // default shake functions
    public void setChocolateShake (ShakeBuilder shakeBuilder) {
        shakeBuilder.setShakeType(EnumShakeType.Chocolate);
        shakeBuilder.setMilkType(EnumMilkType.Normal);
        shakeBuilder.setSugarType(EnumSugarType.Normal);
        shakeBuilder.setSyrupType(EnumSyrupType.Chocolate);
        shakeBuilder.setIceCreamType(EnumIceCreamType.Chocolate);
        shakeBuilder.setBasePrice(230);
    }
    public void setCoffeeShake (ShakeBuilder shakeBuilder) {
        shakeBuilder.setShakeType(EnumShakeType.Coffee);
        shakeBuilder.setMilkType(EnumMilkType.Normal);
        shakeBuilder.setSugarType(EnumSugarType.Normal);
        shakeBuilder.setCoffee(true);
        shakeBuilder.setJelloType(EnumJelloType.Normal);
        shakeBuilder.setBasePrice(250);
    }
    public void setStrawberryShake (ShakeBuilder shakeBuilder) {
        shakeBuilder.setShakeType(EnumShakeType.Strawberry);
        shakeBuilder.setMilkType(EnumMilkType.Normal);
        shakeBuilder.setSugarType(EnumSugarType.Normal);
        shakeBuilder.setSyrupType(EnumSyrupType.Strawberry);
        shakeBuilder.setIceCreamType(EnumIceCreamType.Strawberry);
        shakeBuilder.setBasePrice(200);
    }
    public void setVanillaShake (ShakeBuilder shakeBuilder) {
        shakeBuilder.setShakeType(EnumShakeType.Vanilla);
        shakeBuilder.setMilkType(EnumMilkType.Normal);
        shakeBuilder.setSugarType(EnumSugarType.Normal);
        shakeBuilder.setVanillaFlavouring(true);
        shakeBuilder.setJelloType(EnumJelloType.Normal);
        shakeBuilder.setBasePrice(190);
    }
    public void setZeroShake (ShakeBuilder shakeBuilder) {
        shakeBuilder.setShakeType(EnumShakeType.Zero);
        shakeBuilder.setMilkType(EnumMilkType.Normal);
        shakeBuilder.setSugarType(EnumSugarType.Sweetener);
        shakeBuilder.setVanillaFlavouring(true);
        shakeBuilder.setJelloType(EnumJelloType.SugarFree);
        shakeBuilder.setBasePrice(240);
    }

    // adding extra elements functions
    public void setLactoseFree (ShakeBuilder shakeBuilder) {
        shakeBuilder.setMilkType(EnumMilkType.Almond);
    }
    public void setCandyOnTop (ShakeBuilder shakeBuilder) {
        shakeBuilder.setCandy(true);
    }
    public void setCookiesOnTop (ShakeBuilder shakeBuilder) {
        shakeBuilder.setCookies(true);
    }
    public void setExtraCostList (ShakeBuilder shakeBuilder, ExtraCostList extraCostList) {
        shakeBuilder.setExtraCostList(extraCostList);
    }
}