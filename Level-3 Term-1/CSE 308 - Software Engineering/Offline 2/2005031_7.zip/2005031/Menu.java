// imports
import java.util.Scanner;

// Main class
public class Menu {
    public static void main(String[] args) throws Exception {

        // variable initialization
        Boolean loopVar = true;
        Scanner sc = new Scanner(System.in);
        String commandString;
        ShakeShop shakeShop = new ShakeShop();;
        Boolean start = true;

        // menu loop
        while (loopVar) {
            Boolean loopVar2 = true;

            // starting order / orderlist prompt
            while (loopVar && loopVar2) {

                // prompt
                if (start)
                    System.out.println("Type \'o\' and press enter to start your order");
                else {
                    System.out.println("Type \'o\' and press enter to start another order");
                    System.out.println("Type \'e\' and press enter to close your order");
                }
                System.out.print("Your command: ");
                commandString = sc.nextLine().toLowerCase().trim();
                System.out.println();

                // operations
                if (!start && commandString.equals("e")) {
                    shakeShop.closeOrderList();
                    start = true;
                    loopVar2 = false;
                    break;
                }
                else if (commandString.equals("o")){
                    if (start)
                        shakeShop.startOrderList();
                    shakeShop.startOrder();
                    start = false;
                    break;
                }

                // error print
                System.out.println("Invalid input");
                System.out.println();
            }

            // type of order prompt
            while (loopVar && loopVar2) {

                // prompt
                System.out.println("Enter the type of shake that you will like to order");
                System.out.print("Options: ");
                Boolean first = false;
                for (EnumShakeType shakeType : EnumShakeType.class.getEnumConstants()) {
                    if (first)
                        System.out.print(" / ");
                    first = true;
                    System.out.print(shakeType + " ");
                }
                System.out.println();
                System.out.print("Your command: ");
                commandString = sc.nextLine().toLowerCase().trim();
                System.out.println();

                // operations
                if (shakeShop.typeOfShake(commandString))
                    break;
                
                // error print
                System.out.println("Such shake doesn't exist");
                System.out.println();
            }

            // prompt to make shake lactose free
            while (loopVar && loopVar2) {

                // prompt
                System.out.println("Would you like to make your shake lactose free? y/n");
                System.out.print("Your command: ");
                commandString = sc.nextLine().toLowerCase().trim();
                System.out.println();

                // operations
                if (commandString.equals("y")){
                    shakeShop.makeLactoseFree();
                    break;
                }
                else if (commandString.equals("n"))
                    break;
                
                // error print
                System.out.println("Invalid input");
                System.out.println();
            }
            
            // prompt to add candy
            while (loopVar && loopVar2) {

                // prompt
                System.out.println("Would you like to add candy on top of your shake? y/n");
                System.out.print("Your command: ");
                commandString = sc.nextLine().toLowerCase().trim();
                System.out.println();

                // operations
                if (commandString.equals("y")){
                    shakeShop.addCandyOnTop();
                    break;
                }
                else if (commandString.equals("n"))
                    break;
                
                // error print
                System.out.println("Invalid input");
                System.out.println();
            }
            
            // prompt to add cookies
            while (loopVar && loopVar2) {

                // prompt
                System.out.println("Would you like to add cookies on top of your shake? y/n");
                System.out.print("Your command: ");
                commandString = sc.nextLine().toLowerCase().trim();
                System.out.println();

                // operations
                if (commandString.equals("y")){
                    shakeShop.addCookiesOnTop();
                    shakeShop.closeOrder();
                    break;
                }
                else if (commandString.equals("n")){
                    shakeShop.closeOrder();
                    break;
                }

                // error print
                System.out.println("Invalid input");
                System.out.println();
            }
            
        }
        sc.close();
    }
}
