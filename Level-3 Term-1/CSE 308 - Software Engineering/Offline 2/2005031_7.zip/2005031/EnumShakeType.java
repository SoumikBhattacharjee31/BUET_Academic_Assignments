public enum EnumShakeType {
    Chocolate, Coffee, Strawberry, Vanilla, Zero
}