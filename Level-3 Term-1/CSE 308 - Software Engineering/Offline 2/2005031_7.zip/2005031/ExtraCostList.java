// a hashmap that stores custom shake info

import java.util.HashMap;

public class ExtraCostList {
    // member variable
    HashMap<String, Double> extraCostList;

    // constructor
    ExtraCostList () {
        extraCostList = new HashMap<>();
    }

    // add element to hashmap
    void add (String ingrediant, double value) {
        extraCostList.put(ingrediant, value);
    }

    // get element by key
    double get (String key) {
        return extraCostList.get(key);
    }

    // returns total extra price
    double getTotalPrice () {
        double amount = 0;
        for (double x : extraCostList.values()) {
            amount += x;
        }
        return amount;
    }

    // clearing the hashmap
    void clear () {
        extraCostList.clear();
    }

    // if map is empty
    Boolean empty () {
        return extraCostList.isEmpty();
    }

    // getter
    HashMap<String, Double> getExtraCostList () {
        return extraCostList;
    }
}