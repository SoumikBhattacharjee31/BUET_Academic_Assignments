public enum EnumSyrupType {
    Chocolate, Strawberry
}