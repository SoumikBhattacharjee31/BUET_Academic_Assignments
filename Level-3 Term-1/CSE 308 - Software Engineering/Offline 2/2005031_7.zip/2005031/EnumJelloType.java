public enum EnumJelloType {
    Normal, SugarFree
}