// List of orders

import java.util.ArrayList;

public class ShakeOrderList {
    // member variable
    ArrayList<Shake> shakeOrderList;

    // constructor
    ShakeOrderList() {
        shakeOrderList = new ArrayList<>();
    }

    // add shake to hashmap
    void add (Shake shake) {
        shakeOrderList.add(shake);
    }

    // printing all shakes in the list
    void print () {
        System.out.println("Your orders:");
        int i = 1;
        for (Shake shake : shakeOrderList) {
            System.out.println("Shake "+i++);
            shake.print();
        }
    }

    // clearing the list
    void clear () {
        shakeOrderList.clear();
    }
}
