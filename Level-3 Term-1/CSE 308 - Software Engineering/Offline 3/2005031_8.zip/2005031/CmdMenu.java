// Imports
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;


// Component Interface
interface Component {
    public String getName ();
    public double getSize ();
    public String getType ();
    public String getDirectory ();
    public int getComponentCount ();
    public LocalDateTime getCreationTime ();
    public Component getChild (String name);
    public void details ();
    public void listing ();
    public void delete (String name);
    public void removeChildren ();
    public void recursiveDelete (String name);
    public Component getRoot ();
    public void makeDir (String name);
    public void touch (String name, double size);
    public void makeDrive (String name);
}


// Root component
class Root implements Component {

    // member variables
    private ArrayList<Drive> children;
    private LocalDateTime creationTime;

    // constructor
    Root () {
        this.children = new ArrayList<Drive>();
        creationTime = LocalDateTime.now();
    }

    // member functions
    public String getName () {
        return "~";
    }

    public double getSize() {
        double size = 0;
        for (Drive x : children)
            size += x.getSize();
        return size;
    }

    public String getType () {
        return "Root";
    }

    public String getDirectory () {
        return "~\\";
    }

    public int getComponentCount () {
        int count = 0;
        for (Drive x : children)
            count += x.getComponentCount();
        return count;
    }

    public LocalDateTime getCreationTime () {
        return creationTime;
    }

    public Component getChild (String name) {
        for (Drive x: children)
            if (x.getName().equals(name))
                return x;
        return null;
    }

    public void details () {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
        String formatDateTime = getCreationTime().format(formatter);
        System.out.println("Name: " + getName());
        System.out.println("Type: " + getType());
        System.out.println("Size: " + getSize() + "kB");
        System.out.println("Directory: " + getDirectory());
        System.out.println("Component Count: " + getComponentCount());
        System.out.println("Creation Time: " + formatDateTime);
    }

    public void listing () {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
        for (Drive x : children) {
            String formatDateTime = x.getCreationTime().format(formatter);
            System.out.println(x.getName()+"  "+x.getSize()+"  "+formatDateTime);
        }
    }

    public void removeChildren () {
        for (Drive x: children)
            x.removeChildren();
        this.children.clear();
    }

    public void delete (String name) {
        for (int i=0;i<children.size(); i++)
            if(children.get(i).getName().equals(name)) {
                if (children.get(i).getComponentCount()==0)
                        children.remove(i);
                else
                    System.out.println("Root not empty");
                return;
            }
        System.out.println("Drive not found");
    }

    public void recursiveDelete (String name) {
        for (int i=0;i<children.size(); i++)
            if(children.get(i).getName().equals(name)) {
                children.get(i).removeChildren();
                children.remove(i);
                return;
            }
        System.out.println("Drive not found");
    }

    public Component getRoot () {
        return this;
    }

    public void makeDir (String name) {
        System.out.println("Cannot create a folder in root director");
    }

    public void touch (String name, double size) {
        System.out.println("Cannot create a file in root director");
    }

    public void makeDrive (String name) {
        if (getChild(name)==null) {
            children.add(new Drive(name, this));
            System.out.println("Drive "+name+" created");
        }
        else
            System.out.println("Drive "+name+":\\ already exists");
    }
}


// Drive component
class Drive implements Component {

    // member variables
    private String name;
    private LocalDateTime creationTime;
    private ArrayList<Component> children;
    private Component root;

    // constructor
    Drive (String name, Component root) {
        this.name = name;
        this.creationTime = LocalDateTime.now();
        this.children = new ArrayList<>();
        this.root = root;
    }

    // member variables
    public String getName () {
        return this.name;
    }

    public double getSize() {
        double size = 0;
        for (Component x : children)
            size += x.getSize();
        return size;
    }

    public String getType () {
        return "Drive";
    }

    public String getDirectory () {
        return name+":\\";
    }

    public int getComponentCount () {
        int count = 0;
        for (Component x : children)
            count += x.getComponentCount();
        return count;
    }

    public LocalDateTime getCreationTime () {
        return creationTime;
    }

    public Component getChild (String name) {
        for (Component x: children)
            if (x.getName().equals(name))
                return x;
        return null;
    }

    public void details () {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
        String formatDateTime = getCreationTime().format(formatter);
        System.out.println("Name: " + getName());
        System.out.println("Type: " + getType());
        System.out.println("Size: " + getSize() + "kB");
        System.out.println("Directory: " + getDirectory());
        System.out.println("Component Count: " + getComponentCount());
        System.out.println("Creation Time: " + formatDateTime);
    }

    public void listing () {
        for (Component x : children)
            System.out.println(x.getName()+" "+x.getSize()+" "+x.getCreationTime());
    }

    public void removeChildren () {
        for (Component x: children)
            x.removeChildren();
        this.children.clear();
    }

    public void delete (String name) {
        for (int i=0;i<children.size(); i++)
            if(children.get(i).getName().equals(name)) {
                if (getComponentCount()==0)
                        children.remove(i);
                else
                    System.out.println("Drive not empty");
                return;
            }
        System.out.println("File or folder not found");
    }

    public void recursiveDelete (String name) {
        for (int i=0;i<children.size(); i++)
            if(children.get(i).getName().equals(name)) {
                children.get(i).removeChildren();
                children.remove(i);
                return;
            }
        System.out.println("File or folder not found");
    }

    public Component getRoot () {
        return root;
    }

    public void makeDir (String name) {
        Component cmp = getChild(name);
        if (cmp==null) {
            children.add(new Folder(name, this));
            System.out.println("Directory "+name+"\\ created");
        }
        else
            System.out.println(cmp.getType()+" "+name+" already exists");
    }

    public void touch (String name, double size) {
        Component cmp = getChild(name);
        if (cmp==null) {
            children.add(new File(name, this, size));
            System.out.println("File "+name+" created");
        }
        else
            System.out.println(cmp.getType()+" "+name+" already exists");
    }

    public void makeDrive (String name) {
        System.out.println("You can only create a drive in the root folder");
    }
}


// Folder component
class Folder implements Component {

    // member variables
    private String name;
    private LocalDateTime creationTime;
    private ArrayList<Component> children;
    private Component parent;

    // constructor
    Folder (String name, Component parent) {
        this.name = name;
        this.creationTime = LocalDateTime.now();
        this.parent = parent;
        this.children = new ArrayList<>();
    }

    // member functions
    public String getName () {
        return this.name;
    }

    public double getSize() {
        double size = 0;
        for (Component x : children)
            size += x.getSize();
        return size;
    }

    public String getType () {
        return "Folder";
    }

    public String getDirectory () {
        return parent.getDirectory()+name+"\\";
    }

    public int getComponentCount () {
        int count = 0;
        for (Component x : children)
            count += x.getComponentCount();
        return count;
    }

    public LocalDateTime getCreationTime () {
        return creationTime;
    }

    public Component getChild (String name) {
        for (Component x: children)
            if (x.getName().equals(name))
                return x;
        return null;
    }

    public void details () {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
        String formatDateTime = getCreationTime().format(formatter);
        System.out.println("Name: " + getName());
        System.out.println("Type: " + getType());
        System.out.println("Size: " + getSize() + "kB");
        System.out.println("Directory: " + getDirectory());
        System.out.println("Component Count: " + getComponentCount());
        System.out.println("Creation Time: " + formatDateTime);
    }

    public void listing () {
        for (Component x : children) {
            System.out.println(x.getName()+" "+x.getSize()+" "+x.getCreationTime());
            x.listing();
        }
    }

    public void removeChildren () {
        for (Component x: children)
            x.removeChildren();
        this.children.clear();
    }

    public void delete (String name) {
        for (int i=0;i<children.size(); i++)
            if(children.get(i).getName().equals(name)) {
                if (getComponentCount()==0)
                        children.remove(i);
                else
                    System.out.println("Drive not empty");
                return;
            }
        System.out.println("File or folder not found");
    }

    public void recursiveDelete (String name) {
        for (int i=0;i<children.size(); i++)
            if(children.get(i).getName().equals(name)) {
                children.get(i).removeChildren();
                children.remove(i);
                return;
            }
        System.out.println("File or folder not found");
    }

    public Component getRoot () {
        return parent.getRoot();
    }

    public void makeDir (String name) {
        Component cmp = getChild(name);
        if (cmp==null) {
            children.add(new Folder(name, this));
            System.out.println("Directory "+name+"\\ created");
        }
        else
            System.out.println(cmp.getType()+" "+name+" already exists");
    }

    public void touch (String name, double size) {
        Component cmp = getChild(name);
        if (cmp==null) {
            children.add(new File(name, this, size));
            System.out.println("File "+name+" created");
        }
        else
            System.out.println(cmp.getType()+" "+name+" already exists");
    }

    public void makeDrive (String name) {
        System.out.println("You can only create a drive in the root folder");
    }
}


// File component
class File implements Component {

    // member variables
    private String name;
    private LocalDateTime creationTime;
    private Component parent;
    private double size;

    // constructor
    File (String name, Component parent, double size) {
        this.name = name;
        this.creationTime = LocalDateTime.now();
        this.parent = parent;
        this.size = size;
    }

    // member functions
    public String getName () {
        return this.name;
    }

    public double getSize() {
        return size;
    }

    public String getType () {
        return "File";
    }

    public String getDirectory () {
        return parent.getDirectory()+name;
    }

    public int getComponentCount () {
        return 1;
    }

    public LocalDateTime getCreationTime () {
        return creationTime;
    }

    public Component getChild (String name) {
        return null;
    }

    public void details () {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
        String formatDateTime = getCreationTime().format(formatter);
        System.out.println("Name: " + getName());
        System.out.println("Type: " + getType());
        System.out.println("Size: " + getSize() + "kB");
        System.out.println("Directory: " + getDirectory());
        System.out.println("Component Count: " + getComponentCount());
        System.out.println("Creation Time: " + formatDateTime);
    }

    public void listing () {}

    public void delete (String name) {}

    public void removeChildren () {}

    public void recursiveDelete (String name) {}

    public Component getRoot () {
        return parent.getRoot();
    }

    public void makeDir (String name) {}
    
    public void touch (String name, double size) {}

    public void makeDrive (String name) {
        System.out.println("You can only create a drive in the root folder");
    }
}


// CMD
class CommandSystem {
    // member variable
    private Component currentDir;

    // constructor
    CommandSystem () {
        currentDir = new Root();
    }

    // member functions

    void changeDir (String dir) {
        // when in root but has <=1 letters in string
        if (currentDir.getRoot() == currentDir && dir.length()<=1) {
                System.out.println("Drive don't exist");
                return;
            }
        
        // when in root or directory will go to a drive
        else if (currentDir.getRoot() == currentDir || (dir.length()>1 && dir.substring(dir.length()-2).equals(":\\"))) {
            String driveName = dir.substring(0,dir.length()-2);
            Component drive = currentDir.getRoot().getChild(driveName);
            if (drive != null) {
                currentDir = drive;
                System.out.println("Entered drive: "+driveName);
            }
            else
                System.out.println("Drive don't exist");
        }
        // go to root
        else if (dir.equals("~")) {
            currentDir = currentDir.getRoot();
            System.out.println("Entered root");
        }
        // go to folder
        else {
            Component cmp = currentDir.getChild(dir);
            if (cmp instanceof File) 
                System.out.println("File cannot be traversed");
            else if (cmp != null) {
                currentDir = cmp;
                System.out.println("Entered folder: "+dir);
            }
            else
                System.out.println("No such directory exists");
        }
    }

    void details (String name) {
        Component cmp = currentDir.getChild(name);
        if (cmp != null)
            cmp.details();
        else
            System.out.println("Such name does not exist");
    }

    void listing () {
        currentDir.listing();
    }

    void delete (String name) {
        currentDir.delete(name);
    }

    void recursiveDelete (String name) {
        currentDir.recursiveDelete(name);
    }

    void makeDir (String name) {
        if (currentDir != currentDir.getRoot()) {
            if (currentDir.getChild(name)==null)
                currentDir.makeDir(name);
            else
                System.out.println("File or folder with similar name already exists");
        }
        else
            System.out.println("Enter a drive first");
    }

    void touch (String name, String size) {
        if (currentDir != currentDir.getRoot()) {
            double sizeNum;
            // see if size is a number
            try {
                sizeNum = Double.parseDouble(size);
            } catch (Exception e) {
                System.out.println("Invalid size");
                return;
            }

            // check if file exists already
            if (currentDir.getChild(name) == null)
                currentDir.touch(name, sizeNum);
            else
                System.out.println("File or folder with similar name already exists");
        }
        else
            System.out.println("Enter a drive first");
    }
    
    public void makeDrive (String name) {
        currentDir.makeDrive(name);
    }
}


public class CmdMenu {
    public static void main(String[] args) {

        // initialize
        Scanner sc = new Scanner(System.in);
        CommandSystem cmdSys = new CommandSystem();
        Boolean endloop = false;

        // command loop
        while (!endloop) {

            // input prompt
            System.out.print("Command: ");
            String strin = sc.nextLine().trim();
            System.out.println();
            String[] tokens = strin.split(" ");

            // command switch
            try {
                switch (tokens[0]) {

                    case "mkdrive":
                        cmdSys.makeDrive(tokens[1]);
                        break;

                    case "cd":
                        cmdSys.changeDir(tokens[1]);
                        break;

                    case "mkdir":
                        cmdSys.makeDir(tokens[1]);
                        break;

                    case "touch":
                        if (tokens.length==2)
                            cmdSys.touch(tokens[1], "0");
                        else
                            cmdSys.touch(tokens[1], tokens[2]);
                        break;

                    case "list":
                        cmdSys.listing();
                        break;

                    case "ls":
                        cmdSys.details(tokens[1]);
                        break;

                    case "delete":
                        if (tokens[1].equals("-r"))
                            cmdSys.recursiveDelete(tokens[2]);
                        else
                            cmdSys.delete(tokens[1]);
                        break;

                    default:
                        System.out.println("Invalid Command");
                        break;
                }

            } catch (Exception e) {
                System.out.println(e);
            }
        }
        sc.close();
    }
}
