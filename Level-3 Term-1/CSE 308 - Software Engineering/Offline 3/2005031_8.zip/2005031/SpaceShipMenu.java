// imports
import java.util.HashMap;
import java.util.Scanner;

// passenger interface
interface Passenger {
    public void login();
    public void repair();
    public void work();
    public void logout();
}

// crewmate
class Crewmate implements Passenger {
    public void login () {
        System.out.println("Welcome Crewmate!");
    }
    public void repair () {
        System.out.println("Repairing the spaceship.");
    }
    public void work () {
        System.out.println("Doing research");
    }
    public void logout () {
        System.out.println("Bye Bye crewmate.");
    }
}

// abstract passenger decorator
abstract class PassengerWrapper implements Passenger {

    // member variable
    protected Passenger disguise;

    // constructor
    PassengerWrapper (Passenger disguise) {
        this.disguise = disguise;
    }
}

// imposter passenger decorator
class ImposterWrapper extends PassengerWrapper {

    // constructor
    ImposterWrapper (Passenger disguise) {
        super(disguise);
    }

    // member functions
    public void login () {
        disguise.login();
        System.out.println("We won\'t tell anyone; you are an imposter.");
    }

    public void repair () {
        disguise.repair();
        System.out.println("Damaging the spaceship.");
    }
    
    public void work () {
        disguise.work();
        System.out.println("Trying to kill a crewmate.");
        System.out.println("Successfully killed a crewmate.");
    }

    public void logout () {
        disguise.logout();
        System.out.println("See you again Comrade Imposter");
    }
}

// list of passengers
class PassengerList {
    // member variable
    private HashMap<String,Passenger> passengerList;

    // constructor
    PassengerList() {
        this.passengerList = new HashMap<>();
    }

    // member functions
    // adds new passenger
    void add(String id, Passenger passenger) {
        passengerList.put(id, passenger);
    }

    // returns passenger by id
    Passenger get(String id) {
        if (passengerList.containsKey(id))
            return passengerList.get(id);
        return null;
    }
}

class SpaceShip {

    // member variable
    PassengerList passengerList;

    // constructor
    SpaceShip () {
        this.passengerList = new PassengerList();
        for (int i=0; i<10; i++) {
            passengerList.add("crew"+i, new Crewmate());
            passengerList.add("imp"+i, new ImposterWrapper(new Crewmate()));
        }
    }

    // member function
    Passenger login (String id) {
        Passenger passenger = passengerList.get(id);
        if (passenger != null)
            passenger.login();
        else
            System.out.println("Passenger not found");
        return passenger;
    }
}

public class SpaceShipMenu {
    public static void main(String[] args) {

        // initialize
        Scanner sc = new Scanner(System.in);
        Passenger passenger = null;
        SpaceShip spaceShip = new SpaceShip();
        Boolean endloop = false;

        // command loop
        while (!endloop) {

            // input prompt
            System.out.println("--------------------");
            System.out.print("Your Command: ");
            String inStr = sc.nextLine();
            System.out.println();
            System.out.println("--------------------");
            String[] tokens = inStr.split(" ");

            // Errors
            if (tokens.length<1) {
                System.out.println("Please input a command");
                continue;
            }
            if (passenger==null && !tokens[0].equals("login")) {
                System.out.println("Please log in first");
                continue;
            }

            // switch to functions
            switch (tokens[0]) {

                case "login":
                    // errors
                    if(tokens.length<2)
                        System.out.println("Please speify your id");
                    else if (passenger != null)
                        System.out.println("Log out first");
                    // login
                    else
                        passenger = spaceShip.login(tokens[1]);
                    break;

                case "repair":
                    passenger.repair();
                    break;

                case "work":
                    passenger.work();
                    break;

                case "logout":
                    passenger.logout();
                    passenger = null;
                    break;
                case "end":
                    endloop = true;
                    break;

                default:
                    System.out.println("Invalid command");
                    break;
            }
        }
        sc.close();
    }
}
