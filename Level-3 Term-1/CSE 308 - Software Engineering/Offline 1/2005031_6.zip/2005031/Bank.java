package mypack;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Bank {

    // class variables
    private double totalFund;
    private HashMap<String, Accounts> accounts;
    private HashMap<String, Double> loan;
    private HashMap<String, Employees> employeeList;
    private double fxdIntRate;
    private double savIntRate;
    private double stdIntRate;


    // constructor
    public Bank (double initialFund) {
        this.totalFund = initialFund;
        this.accounts = new HashMap<>();
        this.loan = new HashMap<>();
        this.employeeList = new HashMap<>();
        this.fxdIntRate = 15;
        this.savIntRate = 10;
        this.stdIntRate = 5;
    }

    // getters
    public double getTotalFund () {
        return totalFund;
    }

    public double getInterestRate(Accounts account) {
        if (account instanceof FixedDepositAccounts)
            return fxdIntRate;
        else if (account instanceof SavingsAccounts)
            return savIntRate;
        else if (account instanceof StudentAccounts)
            return stdIntRate;
        return 10;
    }
    public void setInterestRate(String accType, double amount) {
        switch (accType) {
            case "fixed deposit":
                fxdIntRate = amount;
                break;
            case "savings":
                savIntRate = amount;
                break;
            case "student":
                stdIntRate = amount;
                break;
            default:
                System.out.println("Something went wrong");
        }
    }

    public void setFxdIntRate(double fxdIntRate) {
        this.fxdIntRate = fxdIntRate;
    }

    public void setSavIntRate(double savIntRate) {
        this.savIntRate = savIntRate;
    }

    public void setStdIntRate(double stdIntRate) {
        this.stdIntRate = stdIntRate;
    }


    public String createAccount (String userName, String accType, double initDeposit) {
        Accounts account;

        // conditions for not creating  account
        if (accType == "fixed" && initDeposit < 100_000)
            return "Initial deposit is too low to open an account. Please provide at least 100,000 USD";
        else if (accounts.containsKey(userName))
            return "User already exists";

        // account creation
        String out;
        switch (accType) {
            case "fixed":
                account = new FixedDepositAccounts(userName, initDeposit);
                out = "Fixed Deposit";
                break;

            case "savings":
                account = new SavingsAccounts(userName, initDeposit);
                out = "Savings";
                break;

            case "student":
                account = new StudentAccounts(userName, initDeposit);
                out  = "Student";
                break;

            default:
                return "Something went wrong";
        }

        // adding account to bank
        accounts.put(userName, account);
        totalFund += initDeposit;
        return out + " account for "+userName+" Created; initial balance " + initDeposit + "$";
    }

    public String deposit (Accounts account, double amount) {
        totalFund += amount;
        return account.deposit(amount);
    }

    public String withdraw (Accounts account, double amount) {
        String returnString = account.withdraw(amount);
        if (returnString == "The amount was withdrawn successfully")
            totalFund -= amount;
        return returnString;
    }

    public String requestLoan (Accounts account, double amount) {
        double currReqLoan = 0;
        double currLoan = account.getLoan();

        if (loan.containsKey(account.getUserName()))
            currReqLoan = loan.get(account.getUserName());

        if (currLoan + currReqLoan + amount > Accounts.maxLoanLimit(account))
            return "Loan capacity limit reached";
            
        loan.put(account.getUserName(), currReqLoan + amount);
        return "Loan request successful, sent for approval";
    }

    public String queryDeposit (Accounts account) {
        String outline = "Current Balance "+account.getCurrentDeposit()+"$";
        if (account.getLoan()>0)
            outline += ", loan "+account.getLoan()+"$";
        return outline;
    }
    
    public String queryDeposit (String userName) {
        Accounts account = accounts.get(userName);
        String outline = "Current Balance "+account.getCurrentDeposit()+"$";
        if (account.getLoan()>0)
            outline += ", loan "+account.getLoan()+"$";
        return outline;
    }

    public String createEmployee (String employeeName, String type) {
        Employees employee = null;

        switch (type) {
            case "managing director":
                employee = new ManagingDirector(this, employeeName);
                break;

            case "officer":
                employee = new Officer(this, employeeName);
                break;

            case "cashier":
                employee = new Cashier(this, employeeName);
                break;

            default:
                break;
        }

        if (employee == null)
            return "Something went wrong";

        employeeList.put(employeeName, employee);
        return "New employee added successfully";
    }

    public String passYear () {
        FixedDepositAccounts.setCurrYear(FixedDepositAccounts.getCurrYear() + 1);
        for (Map.Entry<String, Accounts> entry : accounts.entrySet()) {
            Accounts account = entry.getValue();
            double interestRate = 10;

            interestRate = getInterestRate(account);

            double interest = account.getCurrentDeposit() * interestRate / 100;
            account.setCurrentDeposit(account.getCurrentDeposit() + interest);
            double loanDeduction = account.getLoan() / 10 + (account instanceof StudentAccounts ? 0 : 500);

            if (account.getCurrentDeposit() < loanDeduction) {
                loanDeduction -= account.getCurrentDeposit();
                account.setCurrentDeposit(0);
                account.setLoan(account.getLoan()+loanDeduction);
            }

            else
                account.setCurrentDeposit(account.getCurrentDeposit() - loanDeduction);
        }
        return "1 year passed";
    }

    public String approveLoan () {
        ArrayList<String> keylist = new ArrayList<>();

        for (Map.Entry<String, Double> entry : loan.entrySet()) {
            String userName = entry.getKey();
            double loan = entry.getValue();

            if (totalFund<loan)
                break;
                
            Accounts account = accounts.get(userName);
            account.setLoan(account.getLoan()+loan);
            account.setCurrentDeposit(account.getCurrentDeposit()+loan);
            keylist.add(userName);
        }

        String outline = "Loan for ";
        Boolean flag=false;

        for (String userName : keylist){
            loan.remove(userName);
            if (flag){
                outline += ", ";
                flag = true;
            }
            outline += userName;
        }

        outline += " approved";
        return outline;
    }

    public static void main(String[] args) {
        Bank bank = new Bank(1_000_000);
        Scanner sc;
        
        // sc = new Scanner(System.in);
        try {sc = new Scanner(new File("input.txt"));} catch (Exception e) {System.out.println(e); sc = new Scanner(System.in);}
        Accounts account = null;
        Employees employee = null;
        // Boolean loopvar = true;

        bank.createEmployee("MD", "managing director");
        bank.createEmployee("S1", "officer");
        bank.createEmployee("S2", "officer");
        bank.createEmployee("C1", "cashier");
        bank.createEmployee("C2", "cashier");
        bank.createEmployee("C3", "cashier");
        bank.createEmployee("C4", "cashier");
        bank.createEmployee("C5", "cashier");
        System.out.println("Bank Created; MD,S1,S2,C1,C2,C3,C4,C5 created");

        // while (loopvar) {
        while (sc.hasNextLine()) {
            try {
                // System.out.print("Enter command: ");
                String line = sc.nextLine();
                String[] tokens = line.split(" ");
                String outline = "";
    
                switch (tokens[0].toLowerCase()) {
                    case "employ":
                        if (account != null || employee != null){
                            outline = "log out first";
                            break;
                        }

                        outline = bank.createEmployee(tokens[1], (tokens[2]+(tokens[2].toLowerCase().equals("managing")?tokens[2]+" "+tokens[3]:tokens[2])).toLowerCase());
                        employee = bank.employeeList.get(tokens[1]);
                        account = null;
                        break;
    
                    case "create":
                    if (account != null || employee != null){
                            outline = "log out first";
                            break;
                        }

                        outline = bank.createAccount (tokens[1], (tokens[2]+(tokens[2].toLowerCase()=="fixed"?" "+tokens[3]:"")).toLowerCase(),
                        Double.parseDouble((tokens[2].toLowerCase().equals("fixed")?tokens[4]:tokens[3]).replace(",", "")));
                        account = bank.accounts.get(tokens[1]);
                        employee = null;
                        break;
    
                    case "deposit":
                        if (account != null)
                            outline = bank.deposit (account, Double.parseDouble (tokens[1].replace (",", "")));
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "withdraw":
                        if (account != null)
                            outline  = bank.withdraw (account, Double.parseDouble (tokens[1].replace (",", "")));
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "query":
                        if (account != null)
                            outline = "" + bank.queryDeposit(account);
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "request":
                        if (account != null)
                            outline = bank.requestLoan (account, Double.parseDouble (tokens[1].replace (",", "")));
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "close":
                        if (employee != null)
                            outline = "Operations for "+employee.employeeName+" closed";
                        else if (account != null)
                            outline = "Transaction Closed for "+account.getUserName();
                        account = null;
                        employee = null;
                        break;
    
                    case "open":
                        if (account != null || employee != null){
                            outline = "log out first";
                            break;
                        }

                        if (bank.accounts.containsKey(tokens[1])){
                            account = bank.accounts.get(tokens[1]);
                            employee  = null;
                            outline = "Welcome back, " + tokens[1];
                        }

                        else if (bank.employeeList.containsKey(tokens[1])) {
                            employee = bank.employeeList.get(tokens[1]);
                            account = null;
                            outline = tokens[1] + " active";
                            if (employee instanceof ManagingDirector || employee instanceof Officer)
                                outline += (bank.loan.size()>0?", there are loan approvals pending":", No loan approval pending");
                        }

                        else
                            outline = "invalid user";
                        break;
    
                    case "approve":
                        if (employee != null && employee instanceof ManagingDirector)
                            outline = ((ManagingDirector)employee).approveLoan();
                        else if (employee != null && employee instanceof Officer)
                            outline = ((Officer)employee).approveLoan();
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "change":
                        if (employee != null && employee instanceof ManagingDirector)
                                outline = ((ManagingDirector)employee) .changeInterestRate (tokens[1], Double.parseDouble (tokens[2].replace (",", "")));
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "lookup":
                        if (employee != null)
                            outline = employee.lookUp(tokens[1]);
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "see":
                        if (employee != null && employee instanceof ManagingDirector)
                            outline = ((ManagingDirector)employee).seeInternalFund();
                        else
                            outline = "You don\'t have permission for this operation";
                        break;
    
                    case "inc":
                        outline = bank.passYear();
                        break;
    
                    // case "stop":
                    //     loopvar = false;
                    //     outline = "Come back again";
                    //     break;
    
                    default:
                        outline = "Invalid input";
                        break;
                }
                System.out.println(outline);
            } catch (Exception e) {
                System.out.println("Something went wrong: "+e);
            }
        }
        sc.close();
    }
}

