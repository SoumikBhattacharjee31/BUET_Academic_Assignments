package mypack;


abstract class Employees {
    protected String employeeName;
    protected Bank bank;

    public Employees (Bank bank, String employeeName) {
        this.bank = bank;
        this.employeeName = employeeName;
    }

    public String lookUp (String userName) {
        return userName+"'s current balance " + bank.queryDeposit(userName)+"$";
    }
}


class ManagingDirector extends Employees {

    public ManagingDirector (Bank bank, String employeeName) {
        super(bank, employeeName);
    }

    public String approveLoan () {
        return bank.approveLoan();
    }

    public String changeInterestRate (String accType, double newInterestRate) {
        switch (accType) {

            case "fixed deposit":
                bank.setInterestRate(accType, newInterestRate);
                break;

            case "savings":
                bank.setInterestRate(accType, newInterestRate);
                break;

            case "student":
                bank.setInterestRate(accType, newInterestRate);
                break;

            default:
                return "Something went wrong";
        }
        return "Successfully changed the interest rate";
    }

    public String seeInternalFund () {
        return "Total Fund "+bank.getTotalFund()+"$";
    }
}


class Officer extends Employees {
    public Officer (Bank bank, String employeeName) {
        super(bank, employeeName);
    }
    
    public String approveLoan () {
        return bank.approveLoan();
    }
}


class Cashier extends Employees {
    public Cashier (Bank bank, String employeeName) {
        super(bank, employeeName);
    }
}

