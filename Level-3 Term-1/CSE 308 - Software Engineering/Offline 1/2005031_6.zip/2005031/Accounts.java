package mypack;


abstract class Accounts {
    
    protected String userName;
    protected double currentDeposit;
    protected double loan;
    protected static int currYear;

    public Accounts (String userName, double initDeposit) {
        this.userName = userName;
        this.currentDeposit = initDeposit;
        this.loan = 0;
    }

    static {
        currYear = 0;
    }

    // getter
    public static int getCurrYear() {
        return currYear;
    }
    public String getUserName () {
        return userName;
    }
    public double getCurrentDeposit() {
        return currentDeposit;
    }
    public double getLoan () {
        return loan;
    }

    // setter
    public void setCurrentDeposit (double newDeposit) {
        currentDeposit = newDeposit;
    }
    public void setLoan (double newloan) {
        loan = newloan;
    }

    public String deposit (double amount) {
        currentDeposit += amount;
        return amount+"$ deposited; current balance "+currentDeposit+"$";
    }

    public String withdraw (double amount) {
        if (currentDeposit < amount)
            return "Invalid transaction; current balance "+ currentDeposit +"$";
        currentDeposit -= amount;
        return "The amount was withdrawn successfully";
    }

    public static double maxLoanLimit (Accounts account) {
        if (account instanceof FixedDepositAccounts)
            return 100_000;
        else if (account instanceof SavingsAccounts)
            return 10_000;
        else if (account instanceof StudentAccounts)
            return 1_000;
        return Double.MAX_VALUE;
    }
}

class FixedDepositAccounts extends Accounts {
    private int accCreationDate;
    
    public FixedDepositAccounts (String userName, double initDeposit) {
        super(userName, initDeposit);
        accCreationDate = currYear;
    }

    public static void setCurrYear(int currYear) {
        FixedDepositAccounts.currYear = currYear;
    }

    @Override
    public String deposit (double amount) {
        if (amount < 50_000)
            return "The amount is too low to deposit. Please provide at least 50,000 USD";
        return super.deposit(amount);
    }

    @Override
    public String withdraw (double amount) {
        if (currYear - accCreationDate >= 1)
            return "Invalid transaction; current balance "+ currentDeposit +"$";
        return super.withdraw(amount);
    }
}

class StudentAccounts extends Accounts {

    public StudentAccounts (String userName, double initDeposit) {
        super(userName, initDeposit);
    }

    @Override
    public String withdraw (double amount) {
        if (amount > 10_000)
            return "Invalid transaction; current balance "+ currentDeposit +"$";
        return super.withdraw(amount);
    }
}

class SavingsAccounts extends Accounts {

    public SavingsAccounts (String userName, double initDeposit) {
        super(userName, initDeposit);
    }
    
    @Override
    public String withdraw (double amount) {
        if (getCurrentDeposit() - amount < 1_000)
            return "Invalid transaction; current balance "+ currentDeposit +"$";
        return super.withdraw(amount);
    }
}