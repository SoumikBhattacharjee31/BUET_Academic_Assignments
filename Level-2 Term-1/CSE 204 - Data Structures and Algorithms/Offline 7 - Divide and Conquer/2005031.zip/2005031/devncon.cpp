#include<iostream>
#include<vector>
#include<utility>
using namespace std;

class result{
    int n;
    vector<pair<int,int>> ret;
public:
    result(int n, vector<pair<int,int>> &ret){
        this->n=n;
        for(int i=0;i<ret.size();i++)
            this->ret.push_back(ret[i]);
    }
    friend ostream& operator << (ostream& ostream, result res);
};

ostream& operator << (ostream& out, result res){
    out<<res.n<<endl;
    if(res.ret.size()!=0)
        out<<"The inverted pairs are ";
    for(int i=0;i<res.ret.size();i++){
        if(i!=0)
            out<<", ";
        out<<"("<<res.ret[i].first<<", "<<res.ret[i].second<<")";
    }
    out<<endl;
    return out;
}

int getInv(int arr[], int l, int r, vector<pair<int,int>> &ret){
    if(l>=r)
        return 0;
    int inv,m=(l+r)/2;
    inv=getInv(arr,l,m,ret)+getInv(arr,m+1,r,ret);
    int ll=l,rr=m+1,tarr[r-l+1],tarrsize=r-l+1;
    while(ll!=m+1&&rr!=r+1)
        if(arr[ll]<=arr[rr])
            ll++;
        else{
            inv+=m-ll+1;
            for(int i=ll;i<=m;i++)
            ret.push_back(make_pair(arr[i],arr[rr]));
            rr++;
        }
    ll=l,rr=m+1;
    for(int i=0;i<tarrsize;i++)
        if(arr[ll]<arr[rr]&&ll<=m||rr==r+1)
            tarr[i]=arr[ll++];
        else
            tarr[i]=arr[rr++];
    for(int i=0;i<tarrsize;i++)
        arr[l+i]=tarr[i];
    return inv;
}

result getallinv(int arr[], int n){
    vector<pair<int,int>> ret;
    result res(getInv(arr,0,n-1,ret),ret);
    return res;
}

int main(){
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
        cin>>arr[i];
    cout<<getallinv(arr,n);
    return 0;
}