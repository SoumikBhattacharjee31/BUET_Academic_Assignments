bst.cpp - Main bst code
linkedlist.hpp - header file that includes linked list
input.txt - input file
output.txt - output file