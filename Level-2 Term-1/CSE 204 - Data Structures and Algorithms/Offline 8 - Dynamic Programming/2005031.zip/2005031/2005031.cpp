#include<iostream>
#include<utility>
#include<vector>
using namespace std;


class knapsack{
    vector<pair<int,int>> data; //weight, value
    int** arr;
    int size;
    int capacity;

public:
    knapsack(vector<pair<int,int>> data, int capacity){
        //initialization and assignment
        this->data=data;
        this->size=data.size();
        this->capacity=capacity;
        arr=new int*[size+1];
        for(int i=0;i<=size;i++)
            arr[i]=new int[capacity];

        //creating dp
        for(int i=0;i<=size;i++)
            arr[i][0]=0;
        for(int i=0;i<=capacity;i++)
            arr[0][i]=0;
        for(int i=1;i<=size;i++)
            for(int j=1;j<=capacity;j++)
                if(data[i-1].first<=j)
                    arr[i][j]=max(arr[i-1][j],arr[i-1][j-data[i-1].first]+data[i-1].second);
                else
                    arr[i][j]=arr[i-1][j];
    }

    ~knapsack(){
        for(int i=0;i<=size;i++)
            delete[] arr[i];
        delete[] arr;
    }

    void printpath(){
        int i,j;
        cout<<arr[size][capacity]<<endl;
        for(i=size,j=capacity;i>0&&j>0;i--)
            if(arr[i-1][j]<arr[i-1][j-data[i-1].first]+data[i-1].second && j-data[i-1].first>=0){
                cout<<data[i-1].first<<" ";
                j-=data[i-1].first;
            }
        cout<<endl;
    }

    void printtable(){
        // print table
        for(int i=0;i<=size;i++){
            for(int j=0;j<=capacity;j++)
                cout<<arr[i][j]<<" ";
            cout<<endl;
        }
    }
};


int main(){
    //file operation initialization
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    //variable initialization and assignment
    int amount,capacity;
    vector<pair<int,int>> data;
    cin>>amount;
    for(int i=0;i<amount;i++){
        int weight,value;
        cin>>weight>>value;
        data.push_back(make_pair(weight,value));
    }
    cin>>capacity;

    //knapsack function call
    knapsack npsk(data,capacity);
    npsk.printpath();
    return 0;
}