#include<iostream>
using namespace std;
void swap(int&a,int &b){
    int temp=a;
    a=b;
    b=temp;
}
int minnext(int start[], int end[], int i){
    int a=0;
    if(end[2*i+1]<end[2*i+2])
        return 2*i+1;
    else if(end[2*i+1]>end[2*i+2])
        return 2*i+2;
    if(start[2*i+1]<start[2*i+2])
        return 2*i+1;
    else
        return 2*i+2;
}
void heapsort(int start[], int end[], int arrsize){
    int newstart[arrsize],newend[arrsize];
    int newstartsize=0;
    for(int i=0;i<arrsize;i++){
        newstart[newstartsize]=start[i];
        newend[newstartsize++]=end[i];
        for(int j=newstartsize-1;j>0&&(newend[(j-1)/2]>newend[j]||(newend[(j-1)/2]==newend[j]&&newstart[(j-1)/2]>newstart[j]));j=(j-1)/2){
            swap(newstart[j],newstart[(j-1)/2]);
            swap(newend[j],newend[(j-1)/2]);
        }
    }
    for(int i=0;i<arrsize;i++){
        start[i]=newstart[0];
        end[i]=newend[0];
        newstart[0]=newstart[--newstartsize];
        newend[0]=newend[newstartsize];
        int k=0;
        for(int j=0;(newend[j]>newend[minnext(newstart,newend,j)]||
        (newend[j]==newend[minnext(newstart,newend,j)]&&
        newstart[j]>newstart[minnext(newstart,newend,j)]))&&
        minnext(newstart,newend,j)<newstartsize;j=k){
            k=minnext(newstart,newend,j);
            swap(newstart[j],newstart[k]);
            swap(newend[j],newend[k]);
        }
    }
}
void  greedysolve(int start[], int end[], int arrsize){
    if(arrsize==0)
        return;
    int ans[arrsize],anssize=0;
    heapsort(start,end,arrsize);

    int presenttime=start[0];
    for(int i=0;i<arrsize;i++){
        if(start[i]<presenttime)
            continue;
        presenttime=end[i];
        ans[anssize++]=i;
    }

    cout<< anssize<<endl;
    for(int i=0;i<anssize;i++)
        cout<<start[ans[i]]<<" "<<end[ans[i]]<<endl;
}
int main(){
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    int n;
    cin>>n;
    int start[n],end[n];
    for(int i=0;i<n;i++){
        int first, second;
        cin>>first>>second;
        start[i]=first;
        end[i]=second;
    }
    greedysolve(start,end,n);
    return 0;
}