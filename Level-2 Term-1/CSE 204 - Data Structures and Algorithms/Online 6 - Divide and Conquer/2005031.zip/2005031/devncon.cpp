#include<iostream>
#include<vector>
#include<utility>
#include<string>
using namespace std;

int getInv(string s, int l, int r){
    if(l>=r)
        return 0;
    int inv,m=(l+r)/2;
    inv=getInv(s,l,m)+getInv(s,m+1,r);
    int ll,rr,count1=0,count2=0;
    bool p=false;
    for(ll=m+1;ll>=l&&s[ll-1]==s[ll]+1;ll--){
        p=true;
        count1++;
    }
    for(rr=m+1;p&&rr<=r&&s[rr+1]==s[rr]-1;rr++){
        count2++;
    }
    if(p)
        inv+=count1+count2+count1*count2;
    return inv;
}


int main(){
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    string s;
    cin>>s;
    cout<<getInv(s,0,s.size()-1);
    return 0;
}