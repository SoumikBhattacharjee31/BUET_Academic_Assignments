#include<iostream>
#include<utility>
#include<vector>
using namespace std;

class trio{
    public:
    int a,b,c;
    trio(int d,int e, int f){
        a=d;
        b=e;
        c=f;
    }
};

class knapsack{
    vector<trio> data; //weight, value
    int* arr;


public:
    knapsack(vector<trio> data1){
        //initialization and assignment
        this->data=data1;
        for(int i=0;i<data.size();i++)
            for(int j=i+1;j<data.size();j++)
                if(data[i].c<data[j].c){
                    trio a=data[i];
                    data[i]=data[j];
                    data[j]=a;
                }
        arr=new int[data.size()+1];

        //creating dp
        arr[0]=0;
        bool ae[data.size()+1]={false};
        cout<<recknapsack(data.size()-1,0,arr,ae);
    }
    int recknapsack(int i, int time, int arr[], bool ae[]){
        if(i<0)return 0;
        if(data[i].a<time)return 0;
        if(ae[i]) return ae[i];
        ae[i]=true;
        int ans=max(recknapsack(i-1,time,arr,ae),recknapsack(i-1,data[i].b,arr,ae)+data[i].c);
        arr[i]=ans;
        return ans;
    }

    ~knapsack(){
        delete[] arr;
    }
};


int main(){
    //file operation initialization
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    //variable initialization and assignment
    int amount;
    vector<trio> data;
    cin>>amount;
    for(int i=0;i<amount;i++){
        int start,end, value;
        cin>>start>>end>>value;
        trio ob(start,end,value);
        data.push_back(ob);
    }

    //knapsack function call
    knapsack npsk(data);
    return 0;
}