myList.hpp     - A header file that contains an abstract class, myList.
arraylist.hpp  - A header file that contains Arr class, which is an implementation of myList class in arraylist form.
linkedlist.hpp - A header file that contains LL class which is an implementation of myList class in linked list form.
myStack.hpp    - Stack implemantation
myQueue.hpp    - Queue implementation

stk_qiu_checker.cpp -Checks stack and queue implementation
task2.cpp      - task 2 solution
consolein.txt  - A txt file that may contain the input for listChecker.cpp file.
consoleout.txt - A txt file that may contain the output for listCheck.cpp file.
input.txt  - A txt file that may contain the input for listChecker.cpp file.
output.txt - A txt file that may contain the output for listCheck.cpp file.
