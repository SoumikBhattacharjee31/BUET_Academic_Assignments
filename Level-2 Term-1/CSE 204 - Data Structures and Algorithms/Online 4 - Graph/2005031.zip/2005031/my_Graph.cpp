#include <iostream>
#include "myQueue.hpp"
using namespace std;
void BFSloop(LL<int> mygraph[], int size, int root, int colour[], int distance[], myQiu<int> &qiu, bool incremented, LL<int> &vertices, LL<int> &edges){
    //cout<<"Root: "<<(incremented?root+1:root)<<endl;
    qiu.enqueue(root);
    colour[root]=1;
    distance[root]=0;
    while(qiu.length()){
        root=qiu.dequeue();
        vertices.pushBack(root+1);
        //cout<<(incremented?root+1:root)<<" "<<distance[root]<<endl;
        mygraph[root].setToBegin();
        for(int i=0;i<mygraph[root].size();i++,mygraph[root].next()){
            if(!colour[mygraph[root].getValue()]){
                qiu.enqueue(mygraph[root].getValue());
                colour[mygraph[root].getValue()]=1;
                distance[mygraph[root].getValue()]=distance[root]+1;
                edges.pushBack(root+1);
                edges.pushBack(mygraph[root].getValue()+1);
            }
        }
    }
}
void BFS(LL<int> mygraph[],int size, int root,bool incremented){
    cout<<"BFS"<<endl;
    myQiu<int> qiu;
    int colour[size]={0};
    int distance[size];
    for(int i=0;i<size;i++)
        distance[i]=1000000007;
    LL<int> vertices, edges;
    BFSloop(mygraph, size, root, colour, distance, qiu, incremented, vertices, edges);
    // for(int i=0;i<size;i++)
    //     if(!colour[i])
    //         BFSloop(arr, size, i, colour, distance, qiu, incremented, vertices, edges);
    cout<<"Vertices: "<<vertices<<"Edges: ";
    edges.printbypair();
}
void recDFS(LL<int> mygraph[],int size, int root, int& time, int colour[],bool incremented, LL<int> &vertices, LL<int> &edges){
    int start=time;
    mygraph[root].setToBegin();
    for(int i=0;i<mygraph[root].size();i++,mygraph[root].next())
        if(!colour[mygraph[root].getValue()]){
            colour[mygraph[root].getValue()]=1;
            time++;
            edges.pushBack(root+1);
            edges.pushBack(mygraph[root].getValue()+1);
            recDFS(mygraph,size,mygraph[root].getValue(),time,colour,incremented,vertices,edges);
        }
    time++;
    vertices.pushBack(root+1);
    //cout<<(incremented?root+1:root)<<" "<<start<<" "<<time<<endl;
}
void DFS(LL<int> mygraph[],int size, int root,bool incremented){
    cout<<"DFS"<<endl;
    LL<int> vertices, edges;
    int colour[size]={0};
    int time=1;
    colour[root]=1;
    //cout<<"Root: "<<(incremented?root+1:root)<<endl;
    recDFS(mygraph,size,root,time,colour,incremented,vertices,edges);
    for(int i=0;i<size;i++)
        if(!colour[i]){
            time++;
            root=i;
            //cout<<"New root: "<<(incremented?root+1:root)<<endl;
            recDFS(mygraph,size,root,time,colour,incremented,vertices,edges);
        }
    cout<<"Vertices: "<<vertices<<"Edges: ";
    edges.printbypair();
}

bool isbiploop(LL<int> mygraph[], int size, int root, int colour[], myQiu<int> &qiu, bool incremented){
    qiu.enqueue(root);
    colour[root]=1;
    while(qiu.length()){
        root=qiu.dequeue();
        mygraph[root].setToBegin();
        for(int i=0;i<mygraph[root].size();i++,mygraph[root].next()){
            //if(!colour[mygraph[root].getValue()]){
                qiu.enqueue(mygraph[root].getValue());
                if(colour[mygraph[root].getValue()]==colour[root])
                    return true;
                colour[mygraph[root].getValue()]=(colour[root]==1?2:1);
            //}
        }
    }
    return false;
}
bool isbip(LL<int> mygraph[],int size, int root,bool incremented){
    cout<<"BFS"<<endl;
    myQiu<int> qiu;
    int colour[size]={0};
    LL<int> vertices, edges;
    bool a=isbiploop(mygraph, size, root, colour, qiu, incremented);
    return a;
    
}

int main(){
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    bool incremented=false;
    int n,m;
    cin>>n>>m;
    LL<int> mygraph[n];
    for(int i=0;i<m;i++){
        int parent, child;
        cin>>parent>>child;
        if(incremented){
            parent--;
            child--; //1
        }
        mygraph[parent].pushBack(child);
    }
    int root=0;
    //cin>>root;
    if(incremented)
        root--; //1
    // BFS(mygraph,n,root,incremented);
    // cout<<endl;
    // DFS(mygraph,n,root,incremented);
    cout<<isbip(mygraph,n,root,incremented);
    return 0;
}