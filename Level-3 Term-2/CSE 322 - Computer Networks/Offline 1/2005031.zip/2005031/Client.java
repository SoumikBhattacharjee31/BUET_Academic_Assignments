import java.io.*;
import java.net.*;
import java.util.*;

class ClientThread implements Runnable {
    String filename;
    Socket socket;
    OutputStream ostream;
    BufferedReader br;
    PrintWriter pw;

    static final String[] VALID_EXTENSIONS = { "jpg", "jpeg", "png", "txt", "mp4" };

    ClientThread(Socket socket, String filename) throws IOException {
        this.socket = socket;
        this.filename = filename;
        this.ostream = socket.getOutputStream();
        this.pw = new PrintWriter(ostream);
        this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    String getExtension(String filename) {
        int lastIndexOfDot = filename.lastIndexOf('.');
        String fileExtension = lastIndexOfDot != -1 ? filename.substring(lastIndexOfDot + 1).toLowerCase() : "";
        return fileExtension;
    }

    @Override
    public void run() {
        String extension = getExtension(filename);
        try {
            File file = new File(filename);
            filename=file.getName();
            if(!file.exists())
                filename="(\\^-^//)";
            pw.write("UPLOAD "+filename+"\r\n\r\n");
            pw.flush();
            String input = br.readLine();
            if(!input.equals("SUCCESS")){
                System.out.println(input);
                return;
            }
            byte[] buffer = new byte[1024];
            int bytesRead;
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
            while ((bytesRead = bis.read(buffer)) != -1) {
                ostream.write(buffer, 0, bytesRead);
            }
            bis.close();
            ostream.flush();
            socket.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        System.out.println("Done");
    }
}

public class Client {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        while (true) {
            Socket socket = new Socket("localhost", 5031);
            System.out.println("Enter filename: ");
            String filename = sc.nextLine();
            ClientThread clientThread = new ClientThread(socket, filename);
            Thread t = new Thread(clientThread);
            t.start();
        }
    }
}
