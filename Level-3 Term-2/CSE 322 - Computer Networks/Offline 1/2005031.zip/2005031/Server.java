import java.net.*;
import java.nio.file.Files;
import java.io.*;
import java.util.*;
import java.util.regex.Pattern;

class MyServerThread implements Runnable {
    Socket socket;
    BufferedReader br;
    PrintWriter pw;
    OutputStream ostream;
    InputStream istream;
    static final String[] VALID_IMG_EXTENSIONS = { "jpg", "jpeg", "png" };
    static final String[] VALID_EXTENSIONS = { "jpg", "jpeg", "png", "txt", "mp4" };

    MyServerThread(Socket socket) throws IOException {
        this.socket = socket;
        this.ostream = socket.getOutputStream();
        this.istream = socket.getInputStream();
        this.pw = new PrintWriter(ostream);
        this.br = new BufferedReader(new InputStreamReader(istream));
    }

    String getExtension(String filename) {
        int lastIndexOfDot = filename.lastIndexOf('.');
        String fileExtension = lastIndexOfDot != -1 ? filename.substring(lastIndexOfDot + 1).toLowerCase() : "";
        return fileExtension;
    }

    void writeResponse(String message, String contentType, long contentSize, Object content) throws Exception {
        pw.write("HTTP/1.0" + message + "\r\n");
        pw.write("Server: Java HTTP Server: 1.0\r\n");
        pw.write("Date: " + new Date() + "\r\n");
        pw.write("Content-Type: " + contentType + "\r\n");
        pw.write("Content-Length: " + contentSize + "\r\n");
        pw.write("\r\n");
        StringBuilder response = new StringBuilder();
        response.append("HTTP/1.0" + message + "\r\n");
        response.append("Server: Java HTTP Server: 1.0\r\n");
        response.append("Date: " + new Date() + "\r\n");
        response.append("Content-Type: " + contentType + "\r\n");
        response.append("Content-Length: " + contentSize + "\r\n");
        response.append("\r\n");
        if (content instanceof String) {
            response.append((String) content);
            pw.write((String) content);
            pw.flush();
        } else if (content instanceof File) {
            pw.flush();
            byte[] buffer = new byte[1024];
            int bytesRead;
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream((File) content));
            while ((bytesRead = bis.read(buffer)) != -1) 
                ostream.write(buffer, 0, bytesRead);
            bis.close();
            ostream.flush();
        }
        logData("Response", response.toString());
    }

    void response_404(String message) throws Exception {
        System.out.println("404: Page Not Found");
        String content = "<html><body><h1>404 Not Found</h1><br/><p>"+message+"</p><script>console.error('404: Page not found')</script></body></html>";
        writeResponse("404: Page Not Found", "text/html", content.length(), content);
    }

    String createImageContent(File file, String extension) throws Exception {
        String base64Image=Base64.getEncoder().encodeToString(Files.readAllBytes(file.toPath()));
        String content = "<html><body><img width=\"1000\" src=\"data:image/"+extension+";base64,"+base64Image+"\" alt=\"Embedded Image\" /></body></html>\r\n";
        return content;
    }

    String createStringContent(File file) throws Exception {
        StringBuilder content = new StringBuilder();
        content.append("<pre>");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while((line=br.readLine())!=null)
            content.append(line).append("\n");
        br.close();
        content.append("</pre>");
        return content.toString();
    }

    String createDirectoryContent(String filename, File file){
        StringBuilder content = new StringBuilder();
        content.append("<h1>Files and Directories:</h1>\r\n<ul>");
        for (File inclusion : Objects.requireNonNull(file.listFiles())) {
            String linkPath = filename + (filename.endsWith("/") ? "" : "/") + inclusion.getName();
            File newfile = new File(linkPath);
            content.append("<li><a href=\"" + linkPath + "\"><i>" + (newfile.isDirectory() ? "<b>" : "")
                    + inclusion.getName() + (newfile.isDirectory() ? "</b>" : "") + "</i></a></li>\r\n");
        }
        content.append("</ul>");
        return content.toString();
    }

    void logData(String type, String content) throws Exception {
        String filename = "log.txt";
        File file = new File(filename);
        if(!file.exists())
            file.createNewFile();
        FileWriter fw = new FileWriter(file, true);
        fw.write(type+":\r\n"+content+"\r\n\r\n");
        fw.close();
    }

    public void run() {
        try {
            String input = this.br.readLine();
            if (input != null && input.length() > 0) {
                logData("Request", input);
                String[] tokens = input.split(" ");
                if (tokens.length>1 && input.startsWith("GET")) {
                    System.out.println(input);
                    String filename = tokens[1];
                    filename=input.substring(input.indexOf("GET ")+4, input.indexOf(" HTTP/1.1")).trim();
                    System.out.println(filename);
                    File file = new File(filename);
                    String fileExtension = getExtension(file.getName());
                    if (tokens[1].equals("/favicon.ico")) {
                        writeResponse("200 OK", "text/html", 0, "");
                    } else if (!file.exists()) {
                        response_404("File not found");
                    } else if (file.isDirectory()) {
                        String content = createDirectoryContent(filename, file);
                        writeResponse("200 OK", "text/html", content.length(), content);
                    } else if (fileExtension.equals("txt")) {
                        String content = createStringContent(file);
                        writeResponse("200 OK", "text/html", content.length(), content);
                    } else if (Arrays.asList(VALID_IMG_EXTENSIONS).contains(fileExtension)) {
                        String content = createImageContent(file, fileExtension);
                        writeResponse("200 OK", "text/html", content.length(), content);
                    } else {
                        writeResponse("200 OK", "application/octet-stream", file.length(), file);
                    }
                }
                else if (tokens.length>1 && input.startsWith("UPLOAD")) {
                    String filename = tokens[1];
                    filename = input.substring(6).trim();
                    if(Pattern.compile("[^\\/:*?\"<>|]+\\.[^\\/:*?\"<>|]+").matcher(filename).matches()==false){
                        pw.write("ERROR: Invalid name\r\n");
                        pw.flush();
                        System.out.println("ERROR: Invalid name");
                        return;
                    }
                    String extension = getExtension(filename);
                    if(!Arrays.asList(VALID_EXTENSIONS).contains(extension)){
                        pw.write("ERROR: Invalid extension\r\n");
                        pw.flush();
                        System.out.println("ERROR: Invalid name");
                        return;
                    }
                    pw.write("SUCCESS\r\n");
                    pw.flush();
                    System.out.println("worked");
                    File uploadDir = new File("Upload/");
                    File outputFile = new File(uploadDir, filename);
                    if(!uploadDir.exists())
                        uploadDir.mkdir();
                    String line;
                    while(!(line=br.readLine()).isEmpty());
                    FileOutputStream fos = new FileOutputStream(outputFile);
                    BufferedOutputStream bos = new BufferedOutputStream(fos);
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    System.out.println("Upload started");
                    while ((bytesRead=istream.read(buffer))!=-1) {
                        bos.write(buffer, 0, bytesRead);
                    }
                    System.out.println("Upload finished");
                    bos.flush();
                    bos.close();
                    fos.close();
                }
                else {
                    response_404("Invalid Request");
                }
            }
            this.socket.close();
        } catch (Exception e) {
            System.out.println("Error: "+e);
        }
    }
}

public class Server {
    static final int PORT = 5031;

    public static void main(String[] args) throws Exception {
        ServerSocket serverSocket = new ServerSocket(PORT);
        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("Client connected");
            new Thread(new MyServerThread(socket)).start();;
        }
    }
}