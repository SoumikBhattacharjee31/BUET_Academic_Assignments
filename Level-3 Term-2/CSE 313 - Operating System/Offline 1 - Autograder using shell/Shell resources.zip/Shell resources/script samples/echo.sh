#!/bin/bash
# A simple shell script for printing

echo "Hello, World!"
echo "Welcome to shell scripting"
