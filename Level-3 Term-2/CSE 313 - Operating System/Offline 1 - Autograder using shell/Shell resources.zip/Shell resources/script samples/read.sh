#!/bin/bash
# A shell script to take user input

echo "Enter your name:"
read name
echo "Hello, $name!"
