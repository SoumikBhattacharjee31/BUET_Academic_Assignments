#!/bin/bash
# A basic shell script with a function

# Define a function
greet() {
    echo "Hello, $1!"
}

# Call the function with an argument
greet "Alice"
