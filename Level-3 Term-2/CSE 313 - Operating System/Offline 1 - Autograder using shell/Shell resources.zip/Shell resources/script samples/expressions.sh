#!/bin/bash
# A shell script for evaluating an expression

num1=5
num2=3

# Using expr for addition
result=$(expr $num1 + $num2)

echo "The sum of $num1 and $num2 is: $result"
