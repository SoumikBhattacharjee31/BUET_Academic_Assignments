#!/bin/bash
# A shell script demonstrating variables

greeting="Good Morning"
name="Alice"
number=100.2

echo "$greeting, $name!"
echo $number
