#!/bin/bash
# A shell script for arithmetic operations

a=10
b=5

echo "a = $a, b = $b"
echo "Addition: $(($a + $b))"
echo "Subtraction: $(($a - $b))"
echo "Multiplication: $(($a * $b))"
echo "Division: $(($a / $b))"
